#ifndef TDK_Croppings_H
#define TDK_Croppings_H

#include "pclviewer.h"
#include "../build/ui_pclviewer.h"

#include <pcl/io/pcd_io.h>
#include <pcl/io/vtk_io.h>

#include <pcl/io/ply_io.h>

#include <pcl/point_types.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include <pcl/surface/gp3.h>


#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/impl/passthrough.hpp>

//sav

#include <iostream>
#include <pcl/common/common.h>

#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/point_types.h>
#include <pcl/surface/mls.h>
#include <pcl/surface/poisson.h>
#include <pcl/filters/passthrough.h>
#include <pcl/io/vtk_io.h>
#include <vtkDataReader.h>
#include <vtkGenericDataObjectReader.h>
#include <vtkStructuredGrid.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <string>
#include <pcl/console/parse.h>
#include <pcl/io/vtk_lib_io.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <pcl/filters/crop_hull.h>
#include <pcl/surface/convex_hull.h>

using namespace pcl;
class TDK_Croppings
{
public:
    TDK_Croppings();
    static void TDK_CubeCroppings(const PointCloud<PointXYZ>::Ptr &mv_inputcloud,PointCloud<PointXYZ>::Ptr &mv_outputcloud,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz);
    static void TDK_CropPlanesPointsFilling(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_cloudoutput,const double &xplus,const double &xminus,const double &yplus,const double &yminus,const double &zplus,const double &zminus,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz);
    static void TDK_FindMaxMin(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,double &maxx,double &minx,double &maxy,double &miny,double &maxz,double &minz );
    static void TDK_SliderRemapedCroppings(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_outputcloud,const double & slidersize,const double & xmaxslider,const double & xminslider,const double & ymaxslider,const double & yminslider,const double & zmaxslider,const double & zminslider,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz);
    static void TDK_SliderRemapedCroppingswithFilling(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_outputcloud,const double & slidersize,const double & xmaxslider,const double & xminslider,const double & ymaxslider,const double & yminslider,const double & zmaxslider,const double & zminslider,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz);


private:
    static void TDK_RandomPlane(PointCloud<PointXYZ>::Ptr & mv_randomplane,const double & numberofpoints,const double & value,const double & maxx,const double & minx,const double & maxy,const double & miny,const double & maxz,const double & minz,const uint & axe);
    static void TDK_FillingCroppedPlane (const PointCloud<PointXYZ>::Ptr & mv_cloudhull,const PointCloud<PointXYZ>::Ptr & mv_randomplane,PointCloud<PointXYZ>::Ptr & mv_cloudoutput);


};

#endif // TDK_Croppings_H
