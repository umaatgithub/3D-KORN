/*#include "tdk_Croppings.h"
#include "pclviewer.h"
#include "../build/ui_pclviewer.h"

#include <pcl/io/pcd_io.h>
#include <pcl/io/vtk_io.h>

#include <pcl/io/ply_io.h>

#include <pcl/point_types.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include <pcl/surface/gp3.h>


#include <pcl/filters/conditional_removal.h>
#include <pcl/filters/impl/passthrough.hpp>

//sav

#include <iostream>
#include <pcl/common/common.h>

#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/point_types.h>
#include <pcl/surface/mls.h>
#include <pcl/surface/poisson.h>
#include <pcl/filters/passthrough.h>
#include <pcl/io/vtk_io.h>
#include <vtkDataReader.h>
#include <vtkGenericDataObjectReader.h>
#include <vtkStructuredGrid.h>
#include <vtkSmartPointer.h>
#include <vtkPolyData.h>
#include <string>
#include <pcl/console/parse.h>
#include <pcl/io/vtk_lib_io.h>
#include <pcl/visualization/pcl_visualizer.h>

#include <pcl/filters/crop_hull.h>
#include <pcl/surface/convex_hull.h>
*/

#include "TDK_PointOperations.h"
#include "TDK_Croppings.h"
#include <iostream>
#include <pcl/common/common.h>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/point_types.h>
#include <pcl/surface/mls.h>
#include <pcl/surface/poisson.h>
#include <pcl/filters/passthrough.h>
//libraries

using namespace pcl;

TDK_Croppings::TDK_Croppings()
{

}

void TDK_Croppings::TDK_FindMaxMin(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,double &maxx,double &minx,double &maxy,double &miny,double &maxz,double &minz ){
    for (size_t i = 0; i < mv_inputcloud->points.size (); ++i)
     {

         if (minx > mv_inputcloud->points[i].x) //check on x axes
             minx = mv_inputcloud->points[i].x;

         if (maxx < mv_inputcloud->points[i].x)
             maxx = mv_inputcloud->points[i].x;


         if (miny > mv_inputcloud->points[i].y) //check on y axes
             miny = mv_inputcloud->points[i].y;

         if (maxy < mv_inputcloud->points[i].y)
             maxy = mv_inputcloud->points[i].y;


         if (minz > mv_inputcloud->points[i].z) //check on z axes
             minz = mv_inputcloud->points[i].z;

         if (maxz < mv_inputcloud->points[i].z)
             maxz = mv_inputcloud->points[i].z;

     }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////
//This function allow to use Croppings with slider value as input
////////////////////////////////////////////////////////////////////////////////////////////////////////
void TDK_Croppings::TDK_SliderRemapedCroppings(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_outputcloud,const double & slidersize,const double & xmaxslider,const double & xminslider,const double & ymaxslider,const double & yminslider,const double & zmaxslider,const double & zminslider,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz){

    double xremapplus,xremapminus,yremapplus,yremapminus,zremapplus,zremapminus;


    ////// Remap the value to fit in the slider range
    xremapplus=maxx - xmaxslider*(maxx-minx)/slidersize;
    xremapminus=xminslider*(maxx-minx)/slidersize+minx;


    yremapplus=maxy - ymaxslider*(maxy-miny)/slidersize;
    yremapminus=yminslider*(maxy-miny)/slidersize+miny;


    zremapplus=maxz - zmaxslider*(maxz-minz)/slidersize;
    zremapminus=zminslider*(maxz-minz)/slidersize+minz;


///////////////call the Croppings
    TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_outputcloud,xremapplus,xremapminus,yremapplus,yremapminus,zremapplus,zremapminus);


}

///////////////////////////////////////////////////////////////////////////////
//This function allow to use Croppings with filling with slider value as input
///////////////////////////////////////////////////////////////////////////////
void TDK_Croppings::TDK_SliderRemapedCroppingswithFilling(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_outputcloud,const double & slidersize,const double & xmaxslider,const double & xminslider,const double & ymaxslider,const double & yminslider,const double & zmaxslider,const double & zminslider,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz){

    double xremapplus,xremapminus,yremapplus,yremapminus,zremapplus,zremapminus;



    ////// Remap the value to fit in the slider range
    xremapplus=maxx - xmaxslider*(maxx-minx)/slidersize;
    xremapminus=xminslider*(maxx-minx)/slidersize+minx;


    yremapplus=maxy - ymaxslider*(maxy-miny)/slidersize;
    yremapminus=yminslider*(maxy-miny)/slidersize+miny;


    zremapplus=maxz - zmaxslider*(maxz-minz)/slidersize;
    zremapminus=zminslider*(maxz-minz)/slidersize+minz;


    ///////////////call the Croppings
    TDK_Croppings::TDK_CropPlanesPointsFilling(mv_inputcloud,mv_outputcloud,xremapplus,xremapminus,yremapplus,yremapminus,zremapplus,zremapminus,maxx,minx,maxy,miny,maxz,minz);

}

///////////////////////////////////////////////////////////////////////////////
//Crop the model and fill the empty plane create by the Croppings
///////////////////////////////////////////////////////////////////////////////
void  TDK_Croppings::TDK_FillingCroppedPlane (const PointCloud<PointXYZ>::Ptr & mv_cloudhull,const PointCloud<PointXYZ>::Ptr & mv_randomplane,PointCloud<PointXYZ>::Ptr & mv_cloudoutput){


    PointCloud<PointXYZ>::Ptr mv_tempcloud  ((new PointCloud<PointXYZ>)) ;

    // from https://github.com/PointCloudLibrary/pcl/issues/234

    /////////extract the shape of the passed point
    pcl::ConvexHull<pcl::PointXYZ> hull;
    hull.setInputCloud(mv_cloudhull);
    hull.setDimension(3);
    std::vector<pcl::Vertices> polygons;
    pcl::PointCloud<pcl::PointXYZ>::Ptr surface_hull (new pcl::PointCloud<pcl::PointXYZ>);
    hull.reconstruct(*surface_hull, polygons);

    pcl::CropHull<pcl::PointXYZ> bb_filter;

    //Crop all the point of the random plane outside the shape
    bb_filter.setDim(2);
    bb_filter.setInputCloud(mv_randomplane);
    bb_filter.setHullIndices(polygons);
    bb_filter.setHullCloud(mv_cloudhull); //LUCA : it was cloud_hully
    bb_filter.setCropOutside(true);
    bb_filter.filter(*mv_tempcloud);

    //add the point to the model
    //LUCA : i added pointers
    *mv_cloudoutput=*mv_cloudoutput+*mv_tempcloud;

}


///////////////////////////////////////////////////////////////////////////////
//Create a random plane at a given x, y or z distance
///////////////////////////////////////////////////////////////////////////////
void TDK_Croppings::TDK_RandomPlane(PointCloud<PointXYZ>::Ptr &mv_randomplane,const double &numberofpoints,const double &value,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz,const uint &axe){

    mv_randomplane->points.resize(numberofpoints);
    int randprecisionx = maxx - minx;
    int randprecisiony = maxy -miny;
    int randprecisionz = maxz - minz;

    switch (axe){
    case 1:

        for (int i = 0; i < numberofpoints; i++) //x plane
        {


            mv_randomplane->points[i].z=(rand() % (randprecisionz+1))*(maxz-minz)/randprecisionz+minz;
            mv_randomplane->points[i].y=(rand() % (randprecisiony+1))*(maxy-miny)/randprecisiony+miny;
            mv_randomplane->points[i].x=value;

        }
    break;

    case 2:
        for (int i = 0; i < numberofpoints; i++) //y plane
        {


            mv_randomplane->points[i].z=(rand() % (randprecisionz+1))*(maxz-minz)/randprecisionz+minz;
            mv_randomplane->points[i].y=value;
            mv_randomplane->points[i].x=(rand() % (randprecisionx+1))*(maxx-minx)/randprecisionx+minx;

        }
        break;


    case 3:

        for (int i = 0; i < numberofpoints; i++) //z plane
        {

            mv_randomplane->points[i].z=value;
            mv_randomplane->points[i].y=(rand() % (randprecisiony+1))*(maxy-miny)/randprecisiony+miny;
            mv_randomplane->points[i].x=(rand() % (randprecisionx+1))*(maxx-minx)/randprecisionx+minx;

        }
        break;
    }

}


///////////////////////////////////////////////////////////////////////////////
//Crop the model and fill the empty plane created by the Croppings
///////////////////////////////////////////////////////////////////////////////
void TDK_Croppings::TDK_CropPlanesPointsFilling(const PointCloud<PointXYZ>::Ptr & mv_inputcloud,PointCloud<PointXYZ>::Ptr & mv_cloudoutput,const double &xplus,const double &xminus,const double &yplus,const double &yminus,const double &zplus,const double &zminus,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz){


    PointCloud<PointXYZ>::Ptr mv_cloudhull  ((new PointCloud<PointXYZ>)) ;

        PointCloud<PointXYZ>::Ptr mv_randomplane  ((new PointCloud<PointXYZ>)) ;
        int numberofpoints=10000;
        int value;

        if (xplus<maxx){
            value=xplus;
            //create a random plane on the x axis and use it to fill the Croppings
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,1);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,xplus,xminus,maxy,miny,maxz,minz);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}

        if (yplus<maxy){
            value=yplus;
            //create a random plane on the x axis and use it to fill the Croppings
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,2);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,yplus,yminus,maxz,minz);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}

        if (zplus<maxz){
            value=zplus;
            //create a random plane on the x axis and use it to fill the Croppings
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,3);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,maxy,miny,zplus,zminus);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}

        if (xminus>minx){
            value=xminus;
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,-1);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,maxy,miny,zplus,zminus);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}

        if (yminus>miny){
            value=yminus;
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,-2);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,maxy,miny,zplus,zminus);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}

        if (zminus>minz){
            value=zminus;
            TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,-3);
            TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,maxy,miny,zplus,zminus);
            TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);}


    /*PointCloud<PointXYZ>::Ptr mv_cloudhull  ((new PointCloud<PointXYZ>)) ;

    PointCloud<PointXYZ>::Ptr mv_randomplane  ((new PointCloud<PointXYZ>)) ;
    int numberofpoints=10000;

    //create a random plane on the x axis and use it to fill the Croppings

    TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,xplus,xminus,maxy,miny,maxz,minz);
    TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);


    //create a random plane on the x axis and use it to fill the Croppings
    TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,1);
    TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,yplus,yminus,maxz,minz);
    TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);


    //create a random plane on the x axis and use it to fill the Croppings
    TDK_Croppings::TDK_RandomPlane(mv_randomplane,numberofpoints,value,maxx,minx,maxy,miny,maxz,minz,2);
    TDK_Croppings::TDK_CubeCroppings(mv_inputcloud,mv_cloudhull,maxx,minx,maxy,miny,zplus,zminus);
    TDK_Croppings::TDK_FillingCroppedPlane(mv_cloudhull,mv_randomplane,mv_cloudoutput);
*/
}


///////////////////////////////////////////////////////////////////////////////
//Crop the model
///////////////////////////////////////////////////////////////////////////////
void TDK_Croppings::TDK_CubeCroppings(const PointCloud<PointXYZ>::Ptr &mv_inputcloud,PointCloud<PointXYZ>::Ptr &mv_outputcloud,const double &maxx,const double &minx,const double &maxy,const double &miny,const double &maxz,const double &minz){


    PassThrough<PointXYZ> pass; //LUCA : it was PointXYZRGB

    ////////Crop along the x axis
    pass.setFilterFieldName ("x");
    pass.setFilterLimits (minx, maxx); //leave Points with z in range of 0.00001 to 6 meters
    pass.setInputCloud (mv_inputcloud);
    pass.filter(*mv_outputcloud);


    ////////Crop along the y axis
    pass.setFilterFieldName ("y");
    pass.setFilterLimits (miny, maxy); //leave Points with z in range of 0.00001 to 6 meters
    pass.setInputCloud (mv_outputcloud);
    pass.filter(*mv_outputcloud);


    ////////Crop along the z axis
    pass.setFilterFieldName ("z");
    pass.setFilterLimits (minz, maxz); //leave Points with z in range of 0.00001 to 6 meters
    pass.setInputCloud (mv_outputcloud);
    pass.filter(*mv_outputcloud);

}
